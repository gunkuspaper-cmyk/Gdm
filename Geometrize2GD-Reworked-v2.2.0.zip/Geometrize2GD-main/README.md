# Geometrize2GD Reworked

A Geode mod for importing Geometrize JSON into Geometry Dash.

## Supported Geometrize primitives

- Rectangle
- Rotated rectangle
- Triangle
- Ellipse
- Rotated ellipse
- Circle
- Line
- Quadratic Bézier
- Polyline

The importer follows the primitive type IDs used by Geometrize Haxe and accepts the normal `shapes` JSON export format.

## Color handling

The remake uses **one Geometry Dash color channel (channel 1)** for imported objects and applies each shape's RGB color through the object's HSV modifiers. This avoids creating a separate color channel for every color in the image.

## Curves

Geometry Dash does not provide a direct editor primitive corresponding to every Geometrize curve. Lines, triangles, quadratic Béziers and polylines are therefore tessellated into thin square objects. The curve segment count is configurable in the source and is currently 12 segments for quadratic Béziers.

## Workflow

1. Select one object in the Geometry Dash editor. It becomes the lower-left anchor of the imported image.
2. Open Geometrize2GD Reworked.
3. Select a Geometrize JSON export.
4. Set the scale and Z-layer offset.
5. Press **Create**.

Geometrize supports rectangle, rotated rectangle, triangle, ellipse, rotated ellipse, circle, line and quadratic Bézier primitives, and the C++/Haxe ecosystem also supports polyline output. See the Geometrize projects for the source format and primitive set.
