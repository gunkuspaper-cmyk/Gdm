#include "ImportPopup.h"

namespace {
    constexpr float PI = 3.14159265358979323846f;
    constexpr float DEFAULT_LINE_THICKNESS = 1.0f;
    constexpr int BEZIER_SEGMENTS = 12;

    float distance(float x1, float y1, float x2, float y2) {
        const float dx = x2 - x1;
        const float dy = y2 - y1;
        return std::sqrt(dx * dx + dy * dy);
    }

    float angleDegrees(float x1, float y1, float x2, float y2) {
        return std::atan2(y2 - y1, x2 - x1) * 180.f / PI;
    }
}

ImportPopup* ImportPopup::create(CCArray* selectedObj) {
    auto* ret = new ImportPopup();
    if (ret && ret->initAnchored(m_popupSize.width, m_popupSize.height, selectedObj)) {
        ret->autorelease();
    } else {
        delete ret;
        ret = nullptr;
    }
    return ret;
}

bool ImportPopup::setup(CCArray* selectedObj) {
    this->m_centerObj = CCArrayExt<GameObject*>(selectedObj)[0];

    m_countLabel = CCLabelBMFont::create("Objects: 0", "bigFont.fnt");
    m_countLabel->setPosition({m_popupSize.width / 2, m_popupSize.height / 2 - 65.f});
    m_countLabel->setVisible(false);
    m_countLabel->setID("count-label");
    m_countLabel->setScale(.4f);

    auto drawLabel = CCLabelBMFont::create("Scale:", "bigFont.fnt");
    drawLabel->setPosition({m_popupSize.width / 2 + 65.f, m_popupSize.height / 2 + 15.f});
    drawLabel->setVisible(false);
    drawLabel->setID("draw-scale-label");
    drawLabel->setScale(.5f);

    auto zLayerLabel = CCLabelBMFont::create("Z-Layer\nOffset:", "bigFont.fnt");
    zLayerLabel->setPosition({m_popupSize.width / 2 - 65.f, m_popupSize.height / 2 + 15.f});
    zLayerLabel->setVisible(false);
    zLayerLabel->setID("zlayer-label");
    zLayerLabel->setScale(.325f);

    m_fileLabel = CCLabelBMFont::create("", "bigFont.fnt");
    m_fileLabel->setColor({0, 255, 0});
    m_fileLabel->setPosition(m_popupSize.width / 2, m_popupSize.height / 2 + 60.f);
    m_fileLabel->setScale(.45f);
    m_fileLabel->setID("file-label");
    m_fileLabel->setVisible(false);

    auto importJsonBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Select File"), this, menu_selector(ImportPopup::importJSON));
    importJsonBtn->setID("import-btn");
    importJsonBtn->setPosition(m_popupSize / 2);

    auto changeJsonBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Change File"), this, menu_selector(ImportPopup::importJSON));
    changeJsonBtn->setVisible(false);
    changeJsonBtn->setPosition({m_popupSize.width / 2, m_popupSize.height / 2 + 90.f});
    changeJsonBtn->setID("change-btn");

    auto parseBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Create"), this, menu_selector(ImportPopup::checkAlert));
    parseBtn->setPosition({m_popupSize.width / 2, m_popupSize.height / 2 - 95.f});
    parseBtn->setVisible(false);
    parseBtn->setID("convert-btn");

    m_drawScaleInput = TextInput::create(50.f, "Float", "bigFont.fnt");
    m_drawScaleInput->setCommonFilter(CommonFilter::Float);
    m_drawScaleInput->setMaxCharCount(7);
    m_drawScaleInput->setString("1");
    m_drawScaleInput->setID("draw-input");
    m_drawScaleInput->setPosition({m_popupSize.width / 2 + 65.f, m_popupSize.height / 2 - 15.f});
    m_drawScaleInput->setVisible(false);
    m_drawScaleInput->getInputNode()->setLabelPlaceholderScale(.5f);
    m_drawScaleInput->getInputNode()->setMaxLabelScale(.6f);
    m_drawScaleInput->setDelegate(this);

    m_zLayerInput = TextInput::create(50.f, "Int", "bigFont.fnt");
    m_zLayerInput->setCommonFilter(CommonFilter::Int);
    m_zLayerInput->setMaxCharCount(5);
    m_zLayerInput->setString("0");
    m_zLayerInput->setID("zlayer-input");
    m_zLayerInput->setPosition({m_popupSize.width / 2 - 65.f, m_popupSize.height / 2 - 15.f});
    m_zLayerInput->setVisible(false);
    m_zLayerInput->getInputNode()->setLabelPlaceholderScale(.6f);
    m_zLayerInput->getInputNode()->setMaxLabelScale(.6f);
    m_zLayerInput->setDelegate(this);

    m_mainLayer->addChild(m_fileLabel);
    m_mainLayer->addChild(m_countLabel);
    m_mainLayer->addChild(drawLabel);
    m_mainLayer->addChild(zLayerLabel);
    m_buttonMenu->addChild(importJsonBtn);
    m_buttonMenu->addChild(changeJsonBtn);
    m_buttonMenu->addChild(parseBtn);
    m_buttonMenu->addChild(m_drawScaleInput);
    m_buttonMenu->addChild(m_zLayerInput);
    return true;
}

void ImportPopup::importJSON(CCObject*) {
    file::FilePickOptions::Filter filter = {
        .description = "Geometrize JSON Output",
        .files = {"*.json"}
    };
    file::FilePickOptions options = {std::nullopt, {filter}};

    m_pickListener.bind([this](Task<Result<std::filesystem::path>>::Event* event) {
        if (event->isCancelled()) {
            return Notification::create("Failed to open file (Task Cancelled)", NotificationIcon::Error)->show();
        }

        auto result = event->getValue();
        if (!result) return;
        if (result->isErr()) {
            return Notification::create(fmt::format("Failed to open file. Error: {}", result->err()), NotificationIcon::Error)->show();
        }

        auto path = result->unwrap();
        if (!path.string().ends_with(".json")) {
            return Notification::create("Wrong file format. It must be a .json file!", NotificationIcon::Error)->show();
        }

        unsigned long fileSize = 0;
        auto* buffer = CCFileUtils::sharedFileUtils()->getFileData(path.string().c_str(), "rb", &fileSize);
        if (!buffer || fileSize == 0) {
            return Notification::create("Failed to read JSON file!", NotificationIcon::Error)->show();
        }

        std::string data(reinterpret_cast<char*>(buffer), fileSize);
        delete[] buffer;

        auto jsonResult = matjson::parse(data);
        if (jsonResult.isErr()) {
            return Notification::create("Failed to parse JSON!", NotificationIcon::Error)->show();
        }

        m_jsonSets = jsonResult.unwrap();
        if (auto shapes = m_jsonSets["shapes"].asArray()) {
            m_jsonSets = shapes.unwrap();
        } else if (auto shapes = m_jsonSets.asArray()) {
            m_jsonSets = shapes.unwrap();
        } else {
            return Notification::create("Failed to parse \"shapes\" key as array!", NotificationIcon::Error)->show();
        }

        m_objsCount = 0;
        for (auto obj : m_jsonSets) {
            auto type = obj["type"].asInt();
            auto score = obj["score"].asDouble();
            if (!type || !score || score.unwrap() <= 0) continue;
            switch (type.unwrap()) {
                case TYPE_RECTANGLE:
                case TYPE_ROTATED_RECTANGLE:
                case TYPE_ELLIPSE:
                case TYPE_ROTATED_ELLIPSE:
                case TYPE_CIRCLE:
                case TYPE_LINE:
                    m_objsCount++;
                    break;
                default:
                    break;
            }
        }

        m_countLabel->setString(fmt::format("Shapes: {}", m_objsCount).c_str());
        m_fileLabel->setString(fmt::format("File: {}", path.filename().string()).c_str());
        m_buttonMenu->getChildByID("import-btn")->setVisible(false);
        m_buttonMenu->getChildByID("change-btn")->setVisible(true);
        m_buttonMenu->getChildByID("convert-btn")->setVisible(true);
        m_mainLayer->getChildByID("draw-scale-label")->setVisible(true);
        m_mainLayer->getChildByID("zlayer-label")->setVisible(true);
        m_fileLabel->setVisible(true);
        m_countLabel->setVisible(true);
        m_zLayerInput->setVisible(true);
        m_drawScaleInput->setVisible(true);

        Notification::create("File is imported", NotificationIcon::Success)->show();
    });
    m_pickListener.setFilter(file::pick(file::PickMode::OpenFile, options));
}

bool ImportPopup::getNumber(const matjson::Value& value, size_t index, float& out) {
    auto number = value[index].asDouble();
    if (!number) return false;
    out = static_cast<float>(number.unwrap());
    return std::isfinite(out);
}

std::vector<float> ImportPopup::getNumbers(const matjson::Value& value) {
    std::vector<float> result;
    std::function<void(const matjson::Value&)> flatten = [&](const matjson::Value& current) {
        if (auto number = current.asDouble()) {
            result.push_back(static_cast<float>(number.unwrap()));
            return;
        }
        if (auto array = current.asArray()) {
            for (auto item : array.unwrap()) flatten(item);
        }
    };
    flatten(value);
    return result;
}

bool ImportPopup::getPoint(const matjson::Value& value, size_t index, float& x, float& y) {
    // Supports both [[x,y], ...] and [x,y,x,y,...] formats.
    if (auto array = value.asArray()) {
        auto points = array.unwrap();
        if (index < points.size()) {
            if (auto point = points[index].asArray()) {
                auto p = point.unwrap();
                if (p.size() >= 2 && getNumber(points[index], 0, x) && getNumber(points[index], 1, y)) return true;
            }
        }
    }

    const size_t base = index * 2;
    return getNumber(value, base, x) && getNumber(value, base + 1, y);
}

void ImportPopup::rgbToHsv(float r, float g, float b, float& h, float& s, float& v) {
    const float maxC = std::max({r, g, b});
    const float minC = std::min({r, g, b});
    const float delta = maxC - minC;

    v = maxC;
    s = maxC <= 0.f ? 0.f : delta / maxC;
    h = 0.f;

    if (delta <= 0.f) return;
    if (maxC == r) h = 60.f * std::fmod((g - b) / delta, 6.f);
    else if (maxC == g) h = 60.f * (((b - r) / delta) + 2.f);
    else h = 60.f * (((r - g) / delta) + 4.f);
    if (h < 0.f) h += 360.f;
}

void ImportPopup::getColorHsv(const matjson::Value& obj, float& h, float& s, float& v) {
    h = s = 0.f;
    v = 1.f;
    auto color = obj["color"].asArray();
    if (!color) return;

    auto c = color.unwrap();
    if (c.size() < 3) return;
    float r = 0.f, g = 0.f, b = 0.f;
    if (!getNumber(obj["color"], 0, r) || !getNumber(obj["color"], 1, g) || !getNumber(obj["color"], 2, b)) return;
    rgbToHsv(r / 255.f, g / 255.f, b / 255.f, h, s, v);
    // GD's unchecked HSV S/V values are multipliers where 1 is neutral.
    // Geometrize gives normalized HSV, so S/V can be used directly.
    s = std::clamp(s, 0.f, 1.f);
    v = std::clamp(v, 0.f, 1.f);
}

void ImportPopup::addObject(int objectID, float x, float y, float scaleX, float scaleY,
                            float rotation, float h, float s, float v) {
    x = m_centerObj->getPositionX() + x * m_drawScale;
    y = m_centerObj->getPositionY() + y * m_drawScale;
    // The GD circle/square primitives used by the original importer are
    // normalized differently from Geometrize's pixel-space dimensions.
    // Keep the original 0.16 / 4 conversion while allowing one scale input.
    scaleX *= m_drawScale * 0.16f;
    scaleY *= m_drawScale * 0.16f;

    // Use ONE base color channel for every generated object.  The per-object
    // HSV payload is the only thing that changes between shapes. Geometry Dash
    // stores HSV as: hue a saturation a value a saturation-checked a value-checked.
    // Hue is in [-180, 180], while unchecked S/V are multipliers.
    //
    // We intentionally leave the saturation/value checkboxes disabled so the
    // values behave as multipliers (0..2), which is the normal Edit Object HSV
    // mode.  Hue is wrapped into [-180, 180].
    const float wrappedHue = std::fmod(h + 180.f, 360.f) - 180.f;
    const float hsvS = std::clamp(s, 0.f, 2.f);
    const float hsvV = std::clamp(v, 0.f, 2.f);

    m_objsString << fmt::format(
        "1,{},2,{},3,{},128,{},129,{},6,{},21,{},41,1,43,{}a{}a{}a0a0,25,{},372,1;",
        objectID, x, y, scaleX, scaleY, rotation,
        COLOR_CHANNEL, wrappedHue, hsvS, hsvV, m_zOrder++
    );
    m_generatedObjects++;
}

void ImportPopup::addLine(float x1, float y1, float x2, float y2, float thickness,
                          float h, float s, float v) {
    const float len = distance(x1, y1, x2, y2);
    if (len <= 0.001f) return;
    addObject(m_SquareId, (x1 + x2) / 2.f, (y1 + y2) / 2.f,
              len / 4.f, thickness / 4.f, angleDegrees(x1, y1, x2, y2), h, s, v);
}

void ImportPopup::addShape(const matjson::Value& obj) {
    auto typeResult = obj["type"].asInt();
    if (!typeResult) return;
    const int type = typeResult.unwrap();

    auto score = obj["score"].asDouble();
    if (score && score.unwrap() <= 0) return;

    const auto data = obj["data"];
    float h, s, v;
    getColorHsv(obj, h, s, v);

    switch (type) {
        case TYPE_RECTANGLE: {
            // Geometrize Rectangle stores opposite corners: x1,y1,x2,y2.
            float x1, y1, x2, y2;
            if (!getNumber(data, 0, x1) || !getNumber(data, 1, y1) || !getNumber(data, 2, x2) || !getNumber(data, 3, y2)) return;
            const float w = std::abs(x2 - x1);
            const float hgt = std::abs(y2 - y1);
            addObject(m_SquareId, (x1 + x2) / 2.f, (y1 + y2) / 2.f, w / 4.f, hgt / 4.f, 0.f, h, s, v);
            break;
        }
        case TYPE_ROTATED_RECTANGLE: {
            // Geometrize RotatedRectangle stores opposite corners plus angle.
            float x1, y1, x2, y2, rotation = 0.f;
            if (!getNumber(data, 0, x1) || !getNumber(data, 1, y1) || !getNumber(data, 2, x2) || !getNumber(data, 3, y2)) return;
            getNumber(data, 4, rotation);
            addObject(m_SquareId, (x1 + x2) / 2.f, (y1 + y2) / 2.f, std::abs(x2 - x1) / 4.f, std::abs(y2 - y1) / 4.f, -rotation, h, s, v);
            break;
        }
        case TYPE_ELLIPSE: {
            // Geometrize stores ellipse radii (rx, ry), not full dimensions.
            float x, y, rx, ry;
            if (!getNumber(data, 0, x) || !getNumber(data, 1, y) || !getNumber(data, 2, rx) || !getNumber(data, 3, ry)) return;
            addObject(m_CircleId, x, y, rx / 4.f, ry / 4.f, 0.f, h, s, v);
            break;
        }
        case TYPE_ROTATED_ELLIPSE: {
            float x, y, rx, ry, rotation = 0.f;
            if (!getNumber(data, 0, x) || !getNumber(data, 1, y) || !getNumber(data, 2, rx) || !getNumber(data, 3, ry)) return;
            getNumber(data, 4, rotation);
            addObject(m_CircleId, x, y, rx / 4.f, ry / 4.f, -rotation, h, s, v);
            break;
        }
        case TYPE_CIRCLE: {
            float x, y, radius;
            if (!getNumber(data, 0, x) || !getNumber(data, 1, y) || !getNumber(data, 2, radius)) return;
            addObject(m_CircleId, x, y, radius / 2.f, radius / 2.f, 0.f, h, s, v);
            break;
        }
        case TYPE_LINE: {
            float x1, y1, x2, y2;
            if (!getNumber(data, 0, x1) || !getNumber(data, 1, y1) || !getNumber(data, 2, x2) || !getNumber(data, 3, y2)) return;
            addLine(x1, y1, x2, y2, DEFAULT_LINE_THICKNESS, h, s, v);
            break;
        }
        default:
            break;
    }
}

void ImportPopup::parseAndPlace() {
    m_objsString.str("");
    m_objsString.clear();
    m_generatedObjects = 0;

    for (auto obj : m_jsonSets) addShape(obj);

    if (m_objsString.str().empty()) {
        Notification::create("No supported shapes were added.", NotificationIcon::Error)->show();
        return onClose(nullptr);
    }

    auto activeEditorLayer = LevelEditorLayer::get();
    auto activeEditorUI = activeEditorLayer->m_editorUI;
    activeEditorUI->onDeleteSelected(nullptr);

    auto objectsArray = activeEditorLayer->createObjectsFromString(m_objsString.str().c_str(), true, true);
    activeEditorUI->flipObjectsY(objectsArray);
    activeEditorLayer->m_undoObjects->addObject(UndoObject::createWithArray(objectsArray, UndoCommand::Paste));
    activeEditorUI->selectObjects(objectsArray, true);
    activeEditorUI->updateButtons();

    Notification::create(
        fmt::format("Converted {} Geometrize shapes into {} GD objects!", m_objsCount, m_generatedObjects),
        NotificationIcon::Success
    )->show();
    keyBackClicked();
}

void ImportPopup::checkAlert(CCObject*) {
    // Every supported Geometrize primitive now maps to one GD object.
    const int estimated = m_objsCount;
    if (estimated > 5000) {
        geode::createQuickPopup(
            "Alert",
            fmt::format("This conversion may place more than <cy>5000 objects</c>\nContinue?", estimated),
            "No", "Yes",
            [this](auto, bool yes) { if (yes) parseAndPlace(); }
        );
    } else {
        parseAndPlace();
    }
}

void ImportPopup::textChanged(CCTextInputNode* input) {
    if (input == m_drawScaleInput->getInputNode()) {
        auto number = utils::numFromString<float>(input->getString());
        if (number.isErr() || number.unwrap() <= 0.f) {
            input->setLabelNormalColor(ccc3(255, 0, 0));
            return;
        }
        input->setLabelNormalColor(ccc3(255, 255, 255));
        m_drawScale = number.unwrap();
    } else if (input == m_zLayerInput->getInputNode()) {
        auto number = utils::numFromString<int>(input->getString());
        if (number.isErr()) {
            input->setLabelNormalColor(ccc3(255, 0, 0));
            return;
        }
        input->setLabelNormalColor(ccc3(255, 255, 255));
        m_zOrder = number.unwrap();
    }
}
