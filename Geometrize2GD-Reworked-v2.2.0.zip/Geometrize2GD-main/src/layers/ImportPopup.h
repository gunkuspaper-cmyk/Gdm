#pragma once

#include <Geode/ui/TextInput.hpp>
#include <matjson.hpp>
#include <sstream>
#include <set>
#include <vector>
#include <cmath>
#include <functional>

using namespace geode::prelude;

class ImportPopup : public geode::Popup<cocos2d::CCArray*>, TextInputDelegate {
protected:
    static constexpr CCSize m_popupSize = CCSize(385.f, 245.f);

    // Geometry Dash primitive objects used as building blocks.
    static constexpr int m_CircleId = 497;
    static constexpr int m_SquareId = 495;

    // Geometrize shape type IDs used by geometrize-haxe.
    static constexpr int TYPE_RECTANGLE = 0;
    static constexpr int TYPE_ROTATED_RECTANGLE = 1;
    static constexpr int TYPE_ELLIPSE = 3;
    static constexpr int TYPE_ROTATED_ELLIPSE = 4;
    static constexpr int TYPE_CIRCLE = 5;
    static constexpr int TYPE_LINE = 8;

    // All imported shapes use ONE GD color channel. Each object's color is
    // represented by its Main Color HSV adjustment (key 43), so importing an
    // image does not require a new color channel for every sampled color.
    static constexpr int COLOR_CHANNEL = 1;

    int m_zOrder = 0;
    int m_objsCount = 0;
    int m_generatedObjects = 0;
    float m_drawScale = 1.f;
    matjson::Value m_jsonSets;
    std::ostringstream m_objsString;
    GameObject* m_centerObj = nullptr;
    TextInput* m_zLayerInput = nullptr;
    CCLabelBMFont* m_fileLabel = nullptr;
    CCLabelBMFont* m_countLabel = nullptr;
    TextInput* m_drawScaleInput = nullptr;
    EventListener<Task<Result<std::filesystem::path>>> m_pickListener;

    void parseAndPlace();
    void importJSON(cocos2d::CCObject* sender);
    void checkAlert(cocos2d::CCObject* sender);
    void textChanged(CCTextInputNode* p0) override;
    bool setup(cocos2d::CCArray* selectedObj) override;

    static bool getNumber(const matjson::Value& value, size_t index, float& out);
    static std::vector<float> getNumbers(const matjson::Value& value);
    static bool getPoint(const matjson::Value& value, size_t index, float& x, float& y);

    void rgbToHsv(float r, float g, float b, float& h, float& s, float& v);
    void getColorHsv(const matjson::Value& obj, float& h, float& s, float& v);

    void addObject(int objectID, float x, float y, float scaleX, float scaleY,
                   float rotation, float h, float s, float v);
    void addLine(float x1, float y1, float x2, float y2, float thickness,
                 float h, float s, float v);

    void addShape(const matjson::Value& obj);

public:
    static ImportPopup* create(cocos2d::CCArray* selectedObj);
};
