# v2.2.0

- Reworked color import to use one Geometry Dash main color channel.
- Added documented per-object HSV serialization (key 43).
- Removed duplicate secondary-color HSV data from generated objects.
- HSV hue is wrapped to the Geometry Dash -180..180 range.
- Saturation/value are clamped to safe unchecked HSV multiplier ranges.

# v2.1.0

- Removed composite primitives that require multiple GD objects.
- Supported shapes are rectangle, rotated rectangle, ellipse, rotated ellipse, circle, and line.
